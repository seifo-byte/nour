# NEXORA Menu

A digital restaurant menu with WhatsApp ordering. Arabic (RTL) and English (LTR).
Plain HTML, CSS and JavaScript. No backend, no Node.js, no paid services, no secrets.

## 1. Project structure
```
nexora-menu/
├── index.html            page structure
├── style.css             design (RTL + LTR)
├── script.js             app logic (you normally never edit it)
├── data/
│   ├── config.js         <-- RESTAURANT SETTINGS (edit this)
│   ├── menu.js           <-- CATEGORIES + PRODUCTS (edit this)
│   └── i18n.js           interface wording in Arabic/English (optional edits)
├── assets/
│   ├── images/           logo, cover, and products/ photos
│   └── icons/logo.svg    browser-tab icon
└── README.md
```

## 2. Customise for a restaurant (simple guide)
Open `data/config.js` in any text editor (VS Code or Notepad). Change only what is between the quotes.

| What | Where in `config.js` |
|---|---|
| Restaurant name (Arabic / English) | `restaurant.nameAr`, `restaurant.nameEn` |
| Description, address, phone | `descriptionAr/En`, `addressAr/En`, `phone` |
| **WhatsApp number (required)** | `restaurant.whatsappNumber` |
| Logo and cover | `logo`, `cover` (put files in `assets/images/`) |
| Opening hours and weekly closing days | `hours.open`, `hours.close`, `hours.closedDays` |
| Dine-in / takeaway / delivery on or off | `ordering.dineIn`, `takeaway`, `delivery` |
| Notes box, table number on or off | `ordering.notes`, `ordering.tableNumber` |
| Minimum order, delivery fee, prep time | `minOrderAmount`, `deliveryFee`, `prepTimeMinutes` (0 = off) |
| Default language / language button | `website.defaultLanguage`, `website.languages` |
| Brand colours | `primaryColor`, `secondaryColor` (hex like `#0f5c45`) |
| Social links | `website.social` (full `https://` links, `""` hides) |
| Remove the yellow "demo" banner | `demoMode: false` |

**WhatsApp number format:** country code + number, digits only, no `+`, no spaces, no leading 0.
Egyptian `01012345678` becomes `"201012345678"`. While it is empty, ordering is blocked with a clear message (nothing is sent to a wrong number).
`ordering.messageLanguage` chooses the language of the message the restaurant receives (`"ar"` recommended).

### Menu (`data/menu.js`)
Each product has Arabic and English name/description, `price`, optional `discountPrice`, `category`, `available` (`false` = "Sold out", cannot be ordered) and optional `image`.
All sample products are **demo content**; replace them.

### Photos
1. Resize each photo to about 800 x 500 px, JPG or WebP, under 150 KB (use squoosh.app).
2. Save it as `assets/images/products/<product-id>.jpg` (for example `burger-classic.jpg`). Keep names lowercase, no spaces.
3. In `menu.js` set `image: "assets/images/products/burger-classic.jpg"`.
Products with no `image` (or a wrong path) automatically show a category placeholder. Replace `logo-placeholder.svg` / `cover-placeholder.svg` or point `logo` / `cover` to your own files.
Product photos get the product name as alt text. The logo and cover are decorative (the name is already in the text).

## 3. Run locally
- Quick: double-click `index.html`.
- Recommended: in a terminal inside the folder run `python -m http.server 8000`, then open http://localhost:8000.

## 4. Upload to GitHub and publish (GitHub Pages)
1. Create an account at github.com, then **New repository**, name it `nexora-menu`, **Public**, **Create**.
2. Click **uploading an existing file**, drag in everything inside the project folder (keep folders), **Commit changes**.
3. **Settings > Pages**: Source = **Deploy from a branch**, Branch = `main`, folder `/ (root)`, **Save**.
4. After 1-2 minutes: `https://YOUR-USERNAME.github.io/nexora-menu/`.
All file paths are relative, so it works in a sub-folder URL like this.

## 5. QR code
1. Copy the live URL. 2. Paste it in a free QR generator (goqr.me, qr-code-generator.com) and download PNG/SVG.
3. Scan with a phone, place a test order, check it arrives on the restaurant's WhatsApp. 4. Print at least 3x3 cm with a white border and test the printed copy.

## 6. How ordering works (be honest with customers)
The customer fills the form, the app opens WhatsApp with the message ready, and the customer must press **Send**. The app never says the order is confirmed: it is confirmed only when the restaurant replies. There is no payment, order history or dashboard, and the cart is stored only on the customer's phone.

## 7. Information you must collect from the restaurant before going live
**A. Required**
- Restaurant name (Arabic and English)
- WhatsApp number that will receive orders (country code 20)
- Default language (Arabic or English)
- Logo and cover image
- Menu: categories, product names, prices, availability (photos strongly recommended)

**B. Optional**
- Address, phone number, opening hours and weekly closing days
- Instagram / Facebook / TikTok / X links
- Delivery fee, minimum order, preparation time
- Brand colours
- Which order types they offer (dine-in / takeaway / delivery) and whether they want table numbers

Anything missing is simply hidden; nothing is invented. Before going live also set `demoMode: false` and replace all demo products.

## 8. Notes
- Fonts (Cairo, Manrope) load from Google Fonts; without internet the phone's default Arabic/Latin font is used.
- Security: no keys, no `eval()`, all text is inserted with `textContent`, links are validated (`https` only), colours are validated.
