/* NEXORA Menu - application logic.
   Reads CONFIG (data/config.js), CATEGORIES + MENU (data/menu.js), STRINGS (data/i18n.js).
   You normally never edit this file. */
(function () {
  "use strict";

  var KEY_CART = "nexora-menu-cart-v2";
  var KEY_LANG = "nexora-menu-lang";
  var state = { cart: {}, category: "all", query: "", lang: "ar", lastUrl: "", lastFocus: null, clearTimer: null };
  var cardUpdaters = {};
  var searchIndex = {};
  var toastTimer = null;

  /* ============ Small helpers ============ */
  function $(id) { return document.getElementById(id); }
  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined) n.textContent = text;   // textContent = safe, never runs HTML
    return n;
  }
  function tl(lang, key) {                           // translate to a given language
    var v = STRINGS[lang][key];
    if (typeof v === "function") return v.apply(null, Array.prototype.slice.call(arguments, 2));
    return v === undefined ? key : v;
  }
  function t(key) { return tl.apply(null, [state.lang].concat(Array.prototype.slice.call(arguments))); }
  function pick(lang, ar, en) { return lang === "ar" ? (ar || en || "") : (en || ar || ""); }
  function storageGet(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function storageSet(k, v) { try { localStorage.setItem(k, v); } catch (e) { /* ignore */ } }
  function latinDigits(s) {                          // Arabic-Indic digits -> 0-9
    return String(s).replace(/[\u0660-\u0669]/g, function (d) { return d.charCodeAt(0) - 0x0660; })
                    .replace(/[\u06F0-\u06F9]/g, function (d) { return d.charCodeAt(0) - 0x06F0; });
  }
  function clean(s, max) { return String(s || "").replace(/[\u0000-\u001F\u007F]/g, " ").replace(/\s+/g, " ").trim().slice(0, max); }
  function norm(s) {                                 // makes Arabic/English search forgiving
    return String(s || "").toLowerCase().replace(/[\u064B-\u065F\u0670\u0640]/g, "")
      .replace(/[\u0623\u0625\u0622]/g, "\u0627").replace(/\u0649/g, "\u064A").replace(/\u0629/g, "\u0647");
  }
  function safeColor(c, fallback) { return /^#[0-9a-fA-F]{3,8}$/.test(String(c || "").trim()) ? c.trim() : fallback; }
  function safeUrl(u) { try { var x = new URL(String(u)); return x.protocol === "https:" ? x.href : ""; } catch (e) { return ""; } }

  /* ============ Money (kept in piasters to avoid 0.1 + 0.2 rounding errors) ============ */
  function cents(n) { return Math.round(Number(n) * 100) || 0; }
  function fmt(c, lang) {
    lang = lang || state.lang;
    try {
      return new Intl.NumberFormat(lang === "ar" ? "ar-EG" : "en-EG",
        { style: "currency", currency: CONFIG.currency || "EGP", minimumFractionDigits: c % 100 === 0 ? 0 : 2, maximumFractionDigits: 2 }).format(c / 100);
    } catch (e) { return (c / 100) + " " + CONFIG.currency; }
  }
  function unitCents(item) {
    var d = cents(item.discountPrice), p = cents(item.price);
    return d > 0 && d < p ? d : p;
  }
  function hasDiscount(item) { return unitCents(item) < cents(item.price); }

  /* ============ Menu data helpers ============ */
  function findItem(id) { for (var i = 0; i < MENU.length; i++) if (MENU[i].id === id) return MENU[i]; return null; }
  function findCat(id) { for (var i = 0; i < CATEGORIES.length; i++) if (CATEGORIES[i].id === id) return CATEGORIES[i]; return null; }
  function itemName(item, lang) { return pick(lang || state.lang, item.nameAr, item.nameEn); }
  function itemDesc(item) { return pick(state.lang, item.descriptionAr, item.descriptionEn); }

  /* ============ Cart ============ */
  function loadCart() {
    try {
      var saved = JSON.parse(storageGet(KEY_CART)) || {};
      Object.keys(saved).forEach(function (id) {
        var item = findItem(id), q = Math.floor(Number(saved[id]));
        if (item && item.available && q > 0) state.cart[id] = Math.min(q, 99);   // drops unknown/unavailable items
      });
    } catch (e) { state.cart = {}; }
  }
  function saveCart() { storageSet(KEY_CART, JSON.stringify(state.cart)); }
  function lines() {
    return Object.keys(state.cart).map(function (id) {
      var item = findItem(id), q = state.cart[id];
      return { item: item, qty: q, unit: unitCents(item), line: unitCents(item) * q };
    });
  }
  function subtotal() { return lines().reduce(function (s, l) { return s + l.line; }, 0); }
  function count() { return lines().reduce(function (s, l) { return s + l.qty; }, 0); }

  function changeQty(id, delta, focusRole) {
    var item = findItem(id);
    if (!item || !item.available) return;
    var next = (state.cart[id] || 0) + delta;
    if (next <= 0) delete state.cart[id]; else state.cart[id] = Math.min(next, 99);
    saveCart();
    if (delta > 0) toast(t("added", itemName(item)));
    renderCart(id, focusRole);
  }
  function removeItem(id) {
    var item = findItem(id);
    delete state.cart[id]; saveCart(); renderCart();
    toast(t("removed", itemName(item)));
    var list = $("cart-list").querySelector("button");
    (list || $("keep-shopping")).focus();
  }
  function clearCart() { state.cart = {}; saveCart(); renderCart(); }

  function toast(msg) {
    var n = $("toast"); n.textContent = msg; n.classList.add("show");
    clearTimeout(toastTimer); toastTimer = setTimeout(function () { n.classList.remove("show"); }, 1800);
  }

  /* ============ Opening hours ============ */
  function hhmm(s) { var m = /^([01]?\d|2[0-3]):([0-5]\d)$/.exec(String(s || "")); return m ? Number(m[1]) * 60 + Number(m[2]) : null; }
  function openStatus() {                            // true / false / null (unknown)
    var h = CONFIG.hours || {}, closed = h.closedDays || [];
    var o = hhmm(h.open), c = hhmm(h.close), now = new Date(), day = now.getDay(), cur = now.getHours() * 60 + now.getMinutes();
    if (o === null || c === null) return closed.length ? closed.indexOf(day) === -1 : null;
    if (o === c) return closed.indexOf(day) === -1;                       // same time = open 24h
    if (o < c) return closed.indexOf(day) === -1 && cur >= o && cur < c;
    if (cur >= o) return closed.indexOf(day) === -1;                      // closes after midnight
    if (cur < c) return closed.indexOf((day + 6) % 7) === -1;
    return false;
  }
  function locale() { return state.lang === "ar" ? "ar-EG" : "en-EG"; }
  function fmtTime(mins) { return new Intl.DateTimeFormat(locale(), { hour: "numeric", minute: "2-digit" }).format(new Date(2000, 0, 1, Math.floor(mins / 60), mins % 60)); }
  function dayName(d) { return new Intl.DateTimeFormat(locale(), { weekday: "long" }).format(new Date(2023, 0, 1 + d)); }

  /* ============ Language + direction ============ */
  function availableLangs() {
    var l = (CONFIG.website.languages || []).filter(function (x) { return x === "ar" || x === "en"; });
    return l.length ? l : ["ar", "en"];
  }
  function setLang(lang) {
    state.lang = lang;
    var html = document.documentElement;
    html.lang = lang; html.dir = lang === "ar" ? "rtl" : "ltr";   // direction switches here
    storageSet(KEY_LANG, lang);
    applyStatic(); renderHeader(); renderCategories(); renderMenu(); renderOrderTypes(); renderCart();
  }
  function applyStatic() {
    each("[data-i18n]", function (n) { n.textContent = t(n.getAttribute("data-i18n")); });
    each("[data-i18n-ph]", function (n) { n.placeholder = t(n.getAttribute("data-i18n-ph")); });
    each("[data-i18n-aria]", function (n) { n.setAttribute("aria-label", t(n.getAttribute("data-i18n-aria"))); });
  }
  function each(sel, fn) { Array.prototype.forEach.call(document.querySelectorAll(sel), fn); }

  /* ============ Header ============ */
  function applyBrand() {
    var w = CONFIG.website, root = document.documentElement.style;
    var p = safeColor(w.primaryColor, "#0f5c45");
    root.setProperty("--accent", p);
    root.setProperty("--accent-soft", safeColor(w.secondaryColor, "#e3f1ec"));
    $("meta-theme").setAttribute("content", p);
    $("demo-banner").hidden = !CONFIG.demoMode;
  }
  function imgWithFallback(img, src, fallbacks) {    // tries src, then each fallback, then hides the image
    var queue = fallbacks.slice();
    img.onerror = function () { var next = queue.shift(); if (next) img.src = next; else { img.onerror = null; img.hidden = true; } };
    img.src = src || queue.shift();
  }
  function renderHeader() {
    var r = CONFIG.restaurant, w = CONFIG.website, L = state.lang;
    var name = pick(L, r.nameAr, r.nameEn);
    $("restaurant-name").textContent = name;
    document.title = clean(pick(L, w.titleAr, w.titleEn), 80) || (name + " | " + (L === "ar" ? "القائمة" : "Menu"));
    $("meta-desc").setAttribute("content", clean(pick(L, w.metaDescriptionAr, w.metaDescriptionEn) || pick(L, r.descriptionAr, r.descriptionEn), 200));
    var tag = pick(L, r.taglineAr, r.taglineEn);
    $("tagline").textContent = tag; $("tagline").hidden = !tag;
    $("description").textContent = pick(L, r.descriptionAr, r.descriptionEn);
    imgWithFallback($("logo"), r.logo, ["assets/images/logo-placeholder.svg"]);
    imgWithFallback($("cover"), r.cover, ["assets/images/cover-placeholder.svg"]);

    var langs = availableLangs(), btn = $("lang-btn");
    btn.hidden = langs.length < 2;
    btn.textContent = tl(L, "langBtn");   // label names the OTHER language
    btn.setAttribute("lang", L === "ar" ? "en" : "ar");

    var info = $("info"); info.textContent = "";
    var st = openStatus();
    if (st !== null) {
      var li = el("li"); var chip = el("span", "status" + (st ? "" : " closed"), st ? t("open") : t("closed")); li.appendChild(chip); info.appendChild(li);
    }
    var h = CONFIG.hours || {}, o = hhmm(h.open), c = hhmm(h.close);
    if (o !== null && c !== null) info.appendChild(el("li", "", t("hours", fmtTime(o), fmtTime(c))));
    if ((h.closedDays || []).length) info.appendChild(el("li", "", t("closedOn", h.closedDays.map(dayName).join(L === "ar" ? "، " : ", "))));
    var prep = Number(CONFIG.ordering.prepTimeMinutes);
    if (prep > 0) info.appendChild(el("li", "", t("prep", prep)));
    var addr = pick(L, r.addressAr, r.addressEn);
    if (addr) info.appendChild(el("li", "", addr));
    var phone = latinDigits(r.phone || "").replace(/[^\d+]/g, "");
    if (phone) {
      var pli = el("li"), a = el("a", "", t("call") + ": "); a.href = "tel:" + phone;
      var num = el("bdi", "", r.phone); a.appendChild(num); pli.appendChild(a); info.appendChild(pli);
    }
    ["instagram", "facebook", "tiktok", "x"].forEach(function (k) {
      var url = safeUrl((w.social || {})[k]);
      if (!url) return;
      var sli = el("li"), sa = el("a", "", t(k)); sa.href = url; sa.target = "_blank"; sa.rel = "noopener noreferrer";
      sli.appendChild(sa); info.appendChild(sli);
    });
  }

  /* ============ Categories + products ============ */
  function renderCategories() {
    var nav = $("categories"); nav.textContent = "";
    [{ id: "all" }].concat(CATEGORIES).forEach(function (cat) {
      var b = el("button", "chip", cat.id === "all" ? t("all") : pick(state.lang, cat.ar, cat.en));
      b.type = "button"; b.setAttribute("aria-pressed", String(state.category === cat.id));
      b.addEventListener("click", function () { state.category = cat.id; renderCategories(); renderMenu(); });
      nav.appendChild(b);
    });
  }
  function productCard(item) {
    var cat = findCat(item.category), name = itemName(item);
    var card = el("article", "card" + (item.available ? "" : " soldout"));
    var media = el("div", "card__img");
    var img = document.createElement("img");
    img.alt = name; img.loading = "lazy"; img.decoding = "async"; img.width = 400; img.height = 250;
    imgWithFallback(img, item.image, [cat ? cat.placeholder : "", "assets/images/products/placeholder-default.svg"].filter(Boolean));
    media.appendChild(img);

    var body = el("div", "card__body");
    body.appendChild(el("h3", "", name));
    body.appendChild(el("p", "", itemDesc(item)));
    var foot = el("div", "card__foot");
    var price = el("div");
    price.appendChild(el("span", "price", fmt(unitCents(item))));
    if (hasDiscount(item)) { var old = el("s", "old", fmt(cents(item.price))); price.appendChild(old); }
    var action = el("div", "card__action");
    foot.appendChild(price); foot.appendChild(action);
    body.appendChild(foot);
    card.appendChild(media); card.appendChild(body);

    function update(focusRole) {                     // shows "Add" or a +/- stepper
      action.textContent = "";
      var q = state.cart[item.id] || 0, focusEl = null;
      if (!item.available) {
        var d = el("button", "add", t("soldOut")); d.type = "button"; d.disabled = true; action.appendChild(d);
      } else if (q === 0) {
        var add = el("button", "add", t("add")); add.type = "button"; add.setAttribute("aria-label", t("addAria", name));
        add.addEventListener("click", function () { changeQty(item.id, 1, "plus"); });
        action.appendChild(add); focusEl = add;
      } else {
        var st = el("div", "stepper");
        var minus = el("button", "", "\u2212"); minus.type = "button"; minus.setAttribute("aria-label", t("dec", name));
        var plus = el("button", "", "+"); plus.type = "button"; plus.setAttribute("aria-label", t("inc", name));
        minus.addEventListener("click", function () { changeQty(item.id, -1, "minus"); });
        plus.addEventListener("click", function () { changeQty(item.id, 1, "plus"); });
        st.appendChild(minus); st.appendChild(el("span", "", String(q))); st.appendChild(plus); action.appendChild(st);
        focusEl = focusRole === "minus" ? minus : plus;
      }
      if (focusRole && focusEl) focusEl.focus();
    }
    cardUpdaters[item.id] = update; update();
    return card;
  }
  function renderMenu() {
    var root = $("menu"); root.textContent = ""; cardUpdaters = {};
    var q = norm(state.query).trim(), shown = 0;
    CATEGORIES.forEach(function (cat) {
      if (state.category !== "all" && state.category !== cat.id) return;
      var items = MENU.filter(function (m) { return m.category === cat.id && (!q || searchIndex[m.id].indexOf(q) !== -1); });
      if (!items.length) return;
      shown += items.length;
      var section = el("section"); section.appendChild(el("h2", "", pick(state.lang, cat.ar, cat.en)));
      var grid = el("div", "grid"); items.forEach(function (i) { grid.appendChild(productCard(i)); });
      section.appendChild(grid); root.appendChild(section);
    });
    if (!shown) root.appendChild(el("p", "empty", MENU.length ? t("noResults") : t("noItems")));
  }

  /* ============ Order settings ============ */
  function orderTypes() {
    var o = CONFIG.ordering, out = [];
    if (o.dineIn) out.push("dinein"); if (o.takeaway) out.push("takeaway"); if (o.delivery) out.push("delivery");
    return out;
  }
  function currentType() { var r = document.querySelector('input[name="orderType"]:checked'); return r ? r.value : ""; }
  function feeCents() { return currentType() === "delivery" ? Math.max(0, cents(CONFIG.ordering.deliveryFee)) : 0; }
  function minCents() { return Math.max(0, cents(CONFIG.ordering.minOrderAmount)); }

  function renderOrderTypes() {
    var box = $("order-types"), prev = currentType(); box.textContent = "";
    var types = orderTypes();
    types.forEach(function (type, i) {
      var label = el("label", "radio"), input = document.createElement("input");
      input.type = "radio"; input.name = "orderType"; input.value = type;
      input.checked = prev ? prev === type : i === 0;
      input.addEventListener("change", syncCheckout);
      label.appendChild(input); label.appendChild(el("span", "", t(type))); box.appendChild(label);
    });
    if (types.length && !currentType()) box.querySelector("input").checked = true;
    $("type-field").hidden = types.length === 0;
    $("notes-field").hidden = !CONFIG.ordering.notes;
    syncCheckout();
  }
  function syncCheckout() {                          // shows/hides fields + updates totals
    var type = currentType();
    $("table-field").hidden = !(type === "dinein" && CONFIG.ordering.tableNumber);
    $("address-field").hidden = type !== "delivery";
    var fee = feeCents(), sub = subtotal();
    $("co-subtotal").textContent = fmt(sub);
    $("co-fee-row").hidden = !(type === "delivery" && fee > 0);
    $("co-fee").textContent = fmt(fee);
    $("co-total").textContent = fmt(sub + fee);
    var closed = openStatus() === false, cn = $("closed-note");
    cn.hidden = !closed; cn.textContent = closed ? t("closedNote") : "";
    var prep = Number(CONFIG.ordering.prepTimeMinutes), pn = $("prep-note");
    pn.hidden = !(prep > 0); pn.textContent = prep > 0 ? t("prep", prep) : "";
  }

  /* ============ Cart rendering ============ */
  function renderCart(changedId, focusRole) {
    var ls = lines(), n = count(), sub = subtotal(), min = minCents();
    $("cart-count").textContent = n;
    $("cart-fab-total").textContent = fmt(sub);
    $("cart-button").hidden = n === 0;
    $("cart-button").setAttribute("aria-label", t("fabAria", n, fmt(sub)));
    $("cart-empty").hidden = n > 0; $("cart-footer").hidden = n === 0;
    $("subtotal").textContent = fmt(sub);
    var belowMin = n > 0 && min > 0 && sub < min, warn = $("min-warning");
    warn.hidden = !belowMin; warn.textContent = belowMin ? t("minOrder", fmt(min)) : "";
    $("go-checkout").disabled = belowMin;

    var list = $("cart-list"); list.textContent = "";
    ls.forEach(function (l) {
      var name = itemName(l.item), li = el("li", "cart-item");
      var info = el("div"); info.appendChild(el("strong", "", name));
      info.appendChild(el("div", "sub", t("each", fmt(l.unit))));
      var qty = el("div", "qty");
      var minus = el("button", "", "\u2212"); minus.type = "button"; minus.setAttribute("aria-label", t("dec", name));
      var plus = el("button", "", "+"); plus.type = "button"; plus.setAttribute("aria-label", t("inc", name));
      minus.addEventListener("click", function () { changeQty(l.item.id, -1); focusCart(l.item.id, "minus"); });
      plus.addEventListener("click", function () { changeQty(l.item.id, 1); focusCart(l.item.id, "plus"); });
      qty.appendChild(minus); qty.appendChild(el("span", "", String(l.qty))); qty.appendChild(plus);
      minus.dataset.id = plus.dataset.id = l.item.id; minus.dataset.role = "minus"; plus.dataset.role = "plus";
      var rm = el("button", "remove", t("remove")); rm.type = "button"; rm.setAttribute("aria-label", t("removeAria", name));
      rm.addEventListener("click", function () { removeItem(l.item.id); });
      li.appendChild(info); li.appendChild(el("strong", "", fmt(l.line))); li.appendChild(qty); li.appendChild(rm);
      list.appendChild(li);
    });
    Object.keys(cardUpdaters).forEach(function (id) { cardUpdaters[id](id === changedId && !isDrawerOpen() ? focusRole : null); });
    resetClearButton();
    syncCheckout();
    if (n === 0 && isDrawerOpen() && $("cart-view").hidden) { showView("cart-view"); }
  }
  function focusCart(id, role) {                     // keeps keyboard focus after the cart list re-renders
    var b = $("cart-list").querySelector('button[data-id="' + id + '"][data-role="' + role + '"]');
    if (b) b.focus(); else $("keep-shopping").focus();
  }
  function resetClearButton() { clearTimeout(state.clearTimer); state.clearTimer = null; $("clear-cart").textContent = t("clear"); }
  function onClearClick() {
    if (state.clearTimer) { clearCart(); $("keep-shopping").focus(); return; }
    $("clear-cart").textContent = t("clearConfirm");
    state.clearTimer = setTimeout(resetClearButton, 4000);
  }

  /* ============ Drawer: open/close, focus trap, views ============ */
  function isDrawerOpen() { return !$("drawer").hidden; }
  function showView(id) {
    ["cart-view", "checkout-view", "sent-view"].forEach(function (v) { $(v).hidden = v !== id; });
    var titles = { "cart-view": "cartTitle", "checkout-view": "checkoutTitle", "sent-view": "sentTitle" };
    $("drawer-title").textContent = t(titles[id]);
    $("drawer").scrollTop = 0; $(id).scrollTop = 0;
    $("drawer-title").focus();
  }
  function setBackgroundInert(on) {
    ["page", "cart-button"].forEach(function (id) { if (on) $(id).setAttribute("inert", ""); else $(id).removeAttribute("inert"); });
    document.body.classList.toggle("no-scroll", on);
  }
  function openDrawer() {
    state.lastFocus = document.activeElement;
    $("overlay").hidden = false; $("drawer").hidden = false; setBackgroundInert(true);
    showView("cart-view");
  }
  function closeDrawer() {
    $("overlay").hidden = true; $("drawer").hidden = true; setBackgroundInert(false);
    var back = state.lastFocus && document.body.contains(state.lastFocus) && !state.lastFocus.hidden ? state.lastFocus : $("menu");
    back.focus();
  }
  function trapTab(e) {                              // keeps Tab inside the open dialog
    if (e.key === "Escape" && isDrawerOpen()) { closeDrawer(); return; }
    if (e.key !== "Tab" || !isDrawerOpen()) return;
    var f = Array.prototype.filter.call($("drawer").querySelectorAll('a[href],button,input,textarea,[tabindex="0"]'),
      function (n) { return !n.disabled && n.offsetParent !== null; });
    if (!f.length) return;
    var first = f[0], last = f[f.length - 1], a = document.activeElement;
    if (e.shiftKey && (a === first || a === $("drawer-title"))) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && a === last) { e.preventDefault(); first.focus(); }
  }

  /* ============ Validation + WhatsApp ============ */
  function setError(id, msg) {
    $(id + "-error").textContent = msg;
    var f = $(id); if (msg) f.setAttribute("aria-invalid", "true"); else f.removeAttribute("aria-invalid");
    return !msg;
  }
  function validate(d) {
    var firstBad = null;
    function check(id, ok, key) { var good = setError(id, ok ? "" : t(key)); if (!good && !firstBad) firstBad = id; }
    check("name", d.name.length >= 2, "errName");
    check("phone", /^(?:\+?20|0)1[0125]\d{8}$/.test(d.phone), "errPhone");
    check("table", !(d.type === "dinein" && CONFIG.ordering.tableNumber) || /^[A-Za-z0-9\u0600-\u06FF-]{1,6}$/.test(d.table), "errTable");
    check("address", d.type !== "delivery" || d.address.length >= 8, "errAddress");
    return firstBad;
  }
  function waNumber() {                              // returns digits like 201012345678, or "" if not set
    var n = latinDigits(CONFIG.restaurant.whatsappNumber || "").replace(/\D/g, "");
    if (/^01[0125]\d{8}$/.test(n)) n = "20" + n.slice(1);    // helps if someone typed 010...
    n = n.replace(/^00/, "");
    return /^\d{10,15}$/.test(n) ? n : "";
  }
  function buildMessage(d) {
    var o = CONFIG.ordering, L = o.messageLanguage === "customer" ? state.lang : (o.messageLanguage === "en" ? "en" : "ar");
    var name = pick(L, CONFIG.restaurant.nameAr, CONFIG.restaurant.nameEn), fee = d.type === "delivery" ? feeCents() : 0;
    var m = [tl(L, "mTitle", name), "", tl(L, "mType") + ": " + tl(L, d.type), tl(L, "mName") + ": " + d.name, tl(L, "mPhone") + ": " + d.phone];
    if (d.type === "dinein" && o.tableNumber) m.push(tl(L, "mTable") + ": " + d.table);
    if (d.type === "delivery") m.push(tl(L, "mAddress") + ": " + d.address);
    m.push("", "*" + tl(L, "mItems") + ":*");
    lines().forEach(function (l) {
      m.push(l.qty + " x " + itemName(l.item, L) + " (" + fmt(l.unit, L) + ") = " + fmt(l.line, L));
    });
    m.push("", tl(L, "mSub") + ": " + fmt(subtotal(), L));
    if (fee > 0) m.push(tl(L, "mFee") + ": " + fmt(fee, L));
    m.push("*" + tl(L, "mTotal") + ": " + fmt(subtotal() + fee, L) + "*");
    if (d.notes) m.push("", tl(L, "mNotes") + ": " + d.notes);
    m.push("", "_" + tl(L, "mFooter") + "_");
    return m.join("\n");
  }
  function formError(msg) { var f = $("form-error"); f.hidden = !msg; f.textContent = msg || ""; }
  function onSubmit(e) {
    e.preventDefault(); formError("");
    var type = currentType();
    if (!type) { formError(t("noTypes")); return; }
    if (count() === 0) { showView("cart-view"); return; }
    if (minCents() > 0 && subtotal() < minCents()) { showView("cart-view"); return; }
    var f = e.target, d = {
      type: type,
      name: clean(f.name.value, 60),
      phone: latinDigits(f.phone.value).replace(/[\s\-()]/g, ""),
      table: clean(latinDigits(f.table.value), 6),
      address: clean(f.address.value, 200),
      notes: CONFIG.ordering.notes ? clean(f.notes.value, 250) : ""
    };
    var bad = validate(d);
    if (bad) { formError(t("fixErrors")); $(bad).focus(); return; }
    var number = waNumber();
    if (!number) { formError(t("waMissing")); return; }
    d.phone = "0" + d.phone.replace(/^(?:\+?20|0)/, "");
    state.lastUrl = "https://wa.me/" + number + "?text=" + encodeURIComponent(buildMessage(d));
    $("reopen").href = state.lastUrl;
    window.open(state.lastUrl, "_blank", "noopener,noreferrer");
    showView("sent-view");
  }

  /* ============ Start ============ */
  function init() {
    MENU.forEach(function (m) { searchIndex[m.id] = norm([m.nameAr, m.nameEn, m.descriptionAr, m.descriptionEn].join(" ")); });
    loadCart(); applyBrand();
    var langs = availableLangs(), saved = storageGet(KEY_LANG), def = CONFIG.website.defaultLanguage;
    var start = langs.indexOf(saved) !== -1 ? saved : (langs.indexOf(def) !== -1 ? def : langs[0]);

    $("search").addEventListener("input", function (e) { state.query = e.target.value; renderMenu(); });
    $("lang-btn").addEventListener("click", function () { setLang(state.lang === "ar" ? "en" : "ar"); $("lang-btn").focus(); });
    $("cart-button").addEventListener("click", openDrawer);
    $("close-drawer").addEventListener("click", closeDrawer);
    $("overlay").addEventListener("click", closeDrawer);
    $("keep-shopping").addEventListener("click", closeDrawer);
    document.addEventListener("keydown", trapTab);
    $("go-checkout").addEventListener("click", function () { showView("checkout-view"); });
    $("back-cart").addEventListener("click", function () { showView("cart-view"); });
    $("edit-order").addEventListener("click", function () { showView("cart-view"); });
    $("clear-cart").addEventListener("click", onClearClick);
    $("checkout-form").addEventListener("submit", onSubmit);
    ["name", "phone", "table", "address"].forEach(function (id) {
      $(id).addEventListener("input", function () { setError(id, ""); formError(""); });
    });
    $("finish").addEventListener("click", function () { clearCart(); $("checkout-form").reset(); formError(""); closeDrawer(); });
    setInterval(function () { renderHeader(); syncCheckout(); }, 60000);   // keeps "open now" fresh
    setLang(start);
  }
  init();
})();
