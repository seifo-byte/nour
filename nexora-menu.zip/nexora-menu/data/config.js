/* ==========================================================================
   NEXORA Menu - RESTAURANT CONFIGURATION
   This is the ONLY file you edit to set up a restaurant.
   Rules: keep the quotes "..." and commas. Leave "" (empty) or 0 to turn an
   optional setting off. Lines marked [DEMO] are sample values: replace them.
   ========================================================================== */

const CONFIG = {

  // Shows a "demo content" banner. Set to false before using with a real client.
  demoMode: true,

  /* ---------- Restaurant information ---------- */
  restaurant: {
    nameAr: "اسم المطعم (نموذج تجريبي)",          // [DEMO] REQUIRED
    nameEn: "Restaurant Name (Demo)",             // [DEMO] REQUIRED
    taglineAr: "",                                // optional short line
    taglineEn: "",
    descriptionAr: "وصف قصير للمطعم يظهر أسفل الاسم. [نص تجريبي]",   // [DEMO]
    descriptionEn: "A short description of the restaurant. [Demo text]", // [DEMO]
    addressAr: "",                                // optional, e.g. "١٢ شارع ..., القاهرة"
    addressEn: "",                                // optional
    phone: "",                                    // optional, e.g. "01012345678"

    // WhatsApp number that RECEIVES orders. REQUIRED before going live.
    // International format, digits only, no "+", no spaces. Egypt = 20.
    // Example: 01012345678  ->  "201012345678"
    whatsappNumber: "",

    logo: "assets/images/logo-placeholder.svg",   // put your logo in assets/images/
    cover: "assets/images/cover-placeholder.svg"  // put your cover photo in assets/images/
  },

  currency: "EGP",

  /* ---------- Opening hours (optional) ---------- */
  hours: {
    open: "12:00",        // 24-hour "HH:MM". Use "" for both to hide opening hours.  [DEMO]
    close: "23:00",       // A closing time after midnight (e.g. "02:00") is supported.  [DEMO]
    closedDays: []        // Weekly closing days: 0=Sunday 1=Monday 2=Tuesday 3=Wednesday 4=Thursday 5=Friday 6=Saturday. Example: [5]
  },

  /* ---------- Ordering settings ---------- */
  ordering: {
    dineIn: true,            // allow dine-in orders
    takeaway: true,          // allow takeaway orders
    delivery: true,          // allow delivery orders (asks for an address)
    notes: true,             // show the customer notes box
    tableNumber: true,       // ask for the table number on dine-in orders
    minOrderAmount: 0,       // minimum order in EGP, 0 = no minimum
    deliveryFee: 0,          // delivery fee in EGP, 0 = no fee
    prepTimeMinutes: 0,      // estimated preparation time in minutes, 0 = hide
    messageLanguage: "ar"    // language of the WhatsApp order message: "ar", "en", or "customer" (same as the customer's screen)
  },

  /* ---------- Website settings ---------- */
  website: {
    defaultLanguage: "ar",           // "ar" or "en"
    languages: ["ar", "en"],         // ["ar"] or ["en"] hides the language button
    primaryColor: "#0f5c45",         // main brand colour (buttons, header)
    secondaryColor: "#e3f1ec",       // light brand colour (soft backgrounds)
    titleAr: "",                     // browser tab title; empty = uses the restaurant name
    titleEn: "",
    metaDescriptionAr: "",           // search-engine description; empty = uses the restaurant description
    metaDescriptionEn: "",
    social: {                        // full https:// links, leave "" to hide
      instagram: "",
      facebook: "",
      tiktok: "",
      x: ""
    }
  }
};
