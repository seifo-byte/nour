/* ==========================================================================
   NEXORA Menu - MENU DATA   (ALL ITEMS BELOW ARE DEMO CONTENT [DEMO])
   Replace them with the real restaurant's menu.
   Each product:
     id            unique text, no spaces (e.g. "burger-classic")
     category      must match a category id below
     nameAr/nameEn, descriptionAr/descriptionEn
     price         number in EGP
     discountPrice optional, lower than price (0 or leave out = no discount)
     image         optional path like "assets/images/products/classic-burger.jpg"
                   (leave "" to show the built-in placeholder)
     available     true/false  (false shows "Sold out" and blocks ordering)
   ========================================================================== */

const CATEGORIES = [
  { id: "burgers",    ar: "برجر",     en: "Burgers",    placeholder: "assets/images/products/placeholder-burgers.svg" },
  { id: "pizza",      ar: "بيتزا",    en: "Pizza",      placeholder: "assets/images/products/placeholder-pizza.svg" },
  { id: "sandwiches", ar: "ساندويتشات", en: "Sandwiches", placeholder: "assets/images/products/placeholder-sandwiches.svg" },
  { id: "drinks",     ar: "مشروبات",  en: "Drinks",     placeholder: "assets/images/products/placeholder-drinks.svg" },
  { id: "desserts",   ar: "حلويات",   en: "Desserts",   placeholder: "assets/images/products/placeholder-desserts.svg" }
];

const MENU = [
  { id: "burger-classic", category: "burgers", nameAr: "برجر لحم كلاسيك", nameEn: "Classic Beef Burger",
    descriptionAr: "قطعة لحم ١٨٠ جم، جبنة شيدر، مخلل، صوص خاص.", descriptionEn: "180g beef patty, cheddar, pickles, house sauce.",
    price: 135, discountPrice: 0, image: "", available: true },
  { id: "burger-double", category: "burgers", nameAr: "دبل سماش برجر", nameEn: "Double Smash Burger",
    descriptionAr: "قطعتان لحم مضغوطتان، بصل مكرمل، جبنة مضاعفة.", descriptionEn: "Two smashed patties, caramelised onions, double cheese.",
    price: 175, discountPrice: 155, image: "", available: true },
  { id: "burger-chicken", category: "burgers", nameAr: "برجر دجاج مقرمش", nameEn: "Crispy Chicken Burger",
    descriptionAr: "صدور دجاج مقرمشة، كول سلو، مايونيز حار.", descriptionEn: "Crispy fried chicken, slaw, spicy mayo.",
    price: 120, discountPrice: 0, image: "", available: true },
  { id: "pizza-margherita", category: "pizza", nameAr: "بيتزا مارجريتا", nameEn: "Margherita Pizza",
    descriptionAr: "صلصة طماطم، موزاريلا، ريحان طازج.", descriptionEn: "Tomato sauce, mozzarella, fresh basil.",
    price: 110, discountPrice: 0, image: "", available: true },
  { id: "pizza-pastrami", category: "pizza", nameAr: "بيتزا بسطرمة", nameEn: "Pastrami Pizza",
    descriptionAr: "بسطرمة، فلفل أخضر، موزاريلا.", descriptionEn: "Pastrami, green peppers, mozzarella.",
    price: 155, discountPrice: 0, image: "", available: false },
  { id: "sand-shawerma", category: "sandwiches", nameAr: "شاورما فراخ", nameEn: "Chicken Shawerma",
    descriptionAr: "فراخ متبلة، ثومية، مخلل، خبز صاج.", descriptionEn: "Marinated chicken, garlic sauce, pickles, saj bread.",
    price: 85, discountPrice: 0, image: "", available: true },
  { id: "sand-hawawshi", category: "sandwiches", nameAr: "حواوشي", nameEn: "Hawawshi",
    descriptionAr: "عيش بلدي محشو لحمة مفرومة متبلة ومحمّر.", descriptionEn: "Baladi bread stuffed with spiced minced beef, grilled.",
    price: 70, discountPrice: 0, image: "", available: true },
  { id: "sand-falafel", category: "sandwiches", nameAr: "ساندويتش فلافل", nameEn: "Falafel Sandwich",
    descriptionAr: "طعمية، طحينة، طماطم، مخلل لفت.", descriptionEn: "Ta'meya, tahini, tomato, pickled turnip.",
    price: 45, discountPrice: 0, image: "", available: true },
  { id: "drink-orange", category: "drinks", nameAr: "عصير برتقال فريش", nameEn: "Fresh Orange Juice",
    descriptionAr: "عصير طازج بدون سكر مضاف.", descriptionEn: "Freshly squeezed, no added sugar.",
    price: 55, discountPrice: 0, image: "", available: true },
  { id: "drink-karkade", category: "drinks", nameAr: "كركديه مثلج", nameEn: "Iced Karkade",
    descriptionAr: "كركديه مثلج بسكر خفيف.", descriptionEn: "Chilled hibiscus, lightly sweetened.",
    price: 40, discountPrice: 0, image: "", available: true },
  { id: "dessert-omali", category: "desserts", nameAr: "أم علي", nameEn: "Om Ali",
    descriptionAr: "عجينة بالحليب والمكسرات والزبيب تُخبز حتى تتحمّر.", descriptionEn: "Warm pastry with milk, nuts and raisins.",
    price: 75, discountPrice: 0, image: "", available: true },
  { id: "dessert-konafa", category: "desserts", nameAr: "كنافة بالقشطة", nameEn: "Konafa with Cream",
    descriptionAr: "كنافة مقرمشة بالقشطة وشربات ماء الزهر.", descriptionEn: "Crisp konafa, qishta cream, orange blossom syrup.",
    price: 85, discountPrice: 0, image: "", available: false }
];
